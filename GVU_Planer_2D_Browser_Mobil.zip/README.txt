GVU Planer 2D – Browser-Version für Handy und PC

Diese Version passt die Oberfläche für kleine Bildschirme an.

WICHTIG: Diese HTML-Datei nutzt die lokale PDF.js-Bibliothek über den relativen Pfad ./pdfjs/build/pdf.mjs. Für den PDF-Import muss der Ordner pdfjs/build mit pdf.mjs und pdf.worker.mjs neben index.html vorhanden sein.

Für den Zugriff am Handy über einen Browser muss die gesamte Web-App (index.html und Ordner pdfjs/build) auf einem Webserver/Webhosting liegen. Eine HTML-Datei, die nur am Windows-PC liegt, ist am Handy nicht automatisch erreichbar. Bei Bereitstellung über https funktionieren lokale PDF-Dateien, die der Benutzer im Handy-Browser auswählt, sofern Browser und Hosting korrekt konfiguriert sind.

Die beiden Gesetzeslinks öffnen weiterhin das RIS und benötigen Internet.
